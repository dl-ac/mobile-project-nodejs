﻿var ApiResponse = function (cnf) {
    this.success = cnf.success;
    this.extras = cnf.extras;
};

module.exports = ApiResponse;